namespace OpenTetsu.Commons.Train;

public enum SpeedLimitType {
    Signal,
    SpeedLimit
}