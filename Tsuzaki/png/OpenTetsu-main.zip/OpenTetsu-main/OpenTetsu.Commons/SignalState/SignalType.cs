namespace OpenTetsu.Commons.SignalState;

public enum SignalType
{
    Standard,
    Switch,
    Home,
    Departure
}