namespace OpenTetsu.Commons.Route;

public enum Direction
{
    Inbound,
    Outbound
}