namespace OpenTetsu.Commons.Route;

public enum StopType
{
    PassengerStop,
    OperationStop,
    Passing
}